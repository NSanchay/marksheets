function myFunction1() {
    var element = document.getElementById("p1");
    element.classList.toggle("mystyle");
  }
  function myFunction2() {
    var element = document.getElementById("p2");
    element.classList.toggle("mystyle");
  }function myFunction3() {
    var element = document.getElementById("p3");
    element.classList.toggle("mystyle");
  }function myFunction4() {
    var element = document.getElementById("p4");
    element.classList.toggle("mystyle");
  }function myFunction5() {
    var element = document.getElementById("p5");
    element.classList.toggle("mystyle");
  }function myFunction6() {
    var element = document.getElementById("p6");
    element.classList.toggle("mystyle");
  }